import { NextResponse } from "next/server"
import { getBaseUrl } from "@/lib/frames"

/**
 * This route handles the Farcaster Frame verification.
 * The .well-known/farcaster.json file is required for Frame verification.
 */
export function GET() {
  return NextResponse.json({
    message: "This is a Farcaster Frame App",
    frames_url: getBaseUrl(),
  })
}

